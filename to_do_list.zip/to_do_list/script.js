// references to html with ids button, add, tbody
const button = document.getElementById("button");
const input = document.getElementById("add");
const tbody = document.querySelector("tbody");

// adding tasks to the list
function addTask() {
  // user input validation - not empty, ignore any spaces
  const task = input.value.trim();
  if (task === "") {
    alert("Please enter your task!");
    return;
  }

  // adding user's task to table
  const newTaskObject = {
    text: task, // string from input.value
    checked: false, // not checked
  };

  createTaskRow(newTaskObject);

  // saving it to local storage
  saveData();

  input.value = "";
}

// create a table row from the task object
function createTaskRow(taskObj) {
  // create row
  const row = document.createElement("tr");
  // add task here (task content)
  const tdTask = document.createElement("td");
  tdTask.textContent = taskObj.text;
  if (taskObj.checked) {
    tdTask.style.textDecoration = "line-through";
    tdTask.style.opacity = "0.5";
  }
  // create check box
  const tdCheck = document.createElement("td");
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.checked = taskObj.checked;
  // css changes when check box says yes/no
  checkbox.onchange = function () {
    tdTask.style.textDecoration = checkbox.checked ? "line-through" : "none";
    tdTask.style.opacity = checkbox.checked ? "0.5" : "1";
    // save to local storage
    saveData();
  };
  tdCheck.appendChild(checkbox);

  // create action buttons for edit and delete
  const tdActions = document.createElement("td");

  const editBtn = document.createElement("button");
  editBtn.textContent = "✏️";
  editBtn.onclick = function () {
    const newText = prompt("Edit your task:", tdTask.textContent);
    if (newText !== null) {
      tdTask.textContent = newText.trim();
      // save to local storage
      saveData();
    }
  };

  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "🗑️";
  deleteBtn.onclick = function () {
    row.remove();
    // save to local storage
    saveData();
  };

  tdActions.appendChild(editBtn);
  tdActions.appendChild(deleteBtn);

  row.appendChild(tdTask);
  row.appendChild(tdCheck);
  row.appendChild(tdActions);

  tbody.appendChild(row);
}

// save all tasks to localStorage
function saveData() {
  const tasks = [];

  for (const row of tbody.rows) {
    const taskText = row.cells[0].textContent;
    const isChecked = row.querySelector("input[type='checkbox']").checked;

    tasks.push({ text: taskText, checked: isChecked });
  }

  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// loading tasks from localStorage
function showTask() {
  const saved = localStorage.getItem("tasks");
  let tasks;

  if (saved) {
    tasks = JSON.parse(saved);
  } else {
    tasks = [];
  }

  tbody.innerHTML = "";

  for (const task of tasks) {
    createTaskRow(task);
  }
}
// showing date and day
const _day = document.getElementById("day");
const _date = document.getElementById("date");
const date = new Date();
const days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
_day.textContent = `Day: ${days[date.getDay()]}`;
_date.textContent = `Date: ${date.toLocaleDateString()}`;

// event listeners
button.onclick = addTask;
showTask();
